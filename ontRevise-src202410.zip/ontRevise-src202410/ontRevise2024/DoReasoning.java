package edu.njupt.radon.exp.ontRevise2024;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import com.clarkparsia.owlapiv3.OWL;
import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.Timer;
import edu.njupt.radon.utils.reasoning.ReasoningTask;

public class DoReasoning {
	
	private OWLOntology onto;
	private OWLOntologyManager manager;
	
	
	public DoReasoning() {
		manager = OWL.manager;
		try {
			onto = manager.createOntology();
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
	}
	
	public boolean isSatisfiable(HashSet<OWLAxiom> axioms, OWLClass ent, Timer checkSat) {	
		boolean isSatisfiable = true;
		manager.addAxioms(onto, axioms);
		//System.out.println("  axiom number : "+onto.getLogicalAxiomCount());
		isSatisfiable = isSatisfiable(onto, ent, null);
		manager.removeAxioms(onto, axioms);
		//System.out.println("  axiom number : "+onto.getLogicalAxiomCount());
		return isSatisfiable;
	}
	

	public boolean isSatisfiable(OWLOntology o, OWLClass concept, Timer checkSat) {
		OWLReasonerFactory reasonerFactory = new PelletReasonerFactory();
		if(o==null) {
			System.out.println("*********** onto is null");
		}
		OWLReasoner owlReasoner = reasonerFactory.createReasoner(o);
		boolean f = true;
		if(o.containsClassInSignature(concept.getIRI())){
			f = owlReasoner.isSatisfiable(concept);
		}
		//owlReasoner.dispose();
		return f;
	}

	public boolean isCoherent(
			HashSet<OWLAxiom> axioms, 
			Timer checkSat) {
		
		boolean flag = true;	
		manager.addAxioms(onto, axioms);		
			
		OWLDataFactory factory = manager.getOWLDataFactory();
		for(OWLClass oc : onto.getClassesInSignature()){
        	if(oc.equals(factory.getOWLNothing())||
        			oc.equals(factory.getOWLThing())){
        		continue;
        	}
			if(!isSatisfiable(onto, oc, checkSat)){
				flag = false;
				break;
			}					
		}			
		manager.removeAxioms(onto, axioms);
		return flag;
	}
	
	public HashSet<OWLClass> getUnsatiConcepts(
			HashSet<OWLAxiom> axioms, 
			Timer checkTimer) {		
		
		manager.addAxioms(onto, axioms);	
		HashSet<OWLClass> uncon = new HashSet<OWLClass>();	
		OWLDataFactory factory = manager.getOWLDataFactory();
		int i = 0;
		for(OWLClass oc : onto.getClassesInSignature()){
        	if(oc.equals(factory.getOWLNothing())||
        			oc.equals(factory.getOWLThing())){
        		continue;
        	}
        	if(checkTimer!=null){
        		checkTimer.start();
        	}        	
        	boolean f = isSatisfiable(onto, oc, checkTimer);
        	//System.out.println(" is satisfiable: "+f);
        	if(checkTimer!=null){
        		checkTimer.stop();
        	}
			if(!f){
				uncon.add(oc);
			}					
		}			
		manager.removeAxioms(onto, axioms);
		return uncon;
	}
}
