package edu.njupt.radon.exp.ontRevise2024;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;

import edu.njupt.radon.repair.ilp.ILPAlgorithm;
import edu.njupt.radon.repair.ilp.ILPTools;
import edu.njupt.radon.repair.ilp.ILPWeights;
import ilog.cplex.IloCplex;

public class CPlexSolution {
	
	public static HashSet<OWLAxiom> repairByCPlex(String resPath, 
			HashSet<HashSet<OWLAxiom>> multiSets, 
			HashMap<OWLAxiom, Double> axiomRankMap){		
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		
		long st = System.currentTimeMillis();
		try {
			// Translate OWL axioms to cplex representation as a model (.mps file)
			ILPWeights.createModel(resPath+"models/", multiSets, inputAxioms, axiomRankMap, 2);
			IloCplex cplex = new IloCplex();
			cplex.importModel(resPath+"models/ilpModel2.mps");
			cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
			cplex.solve();
			solution = ILPTools.getCplexResult(cplex, inputAxioms);
			cplex.end();			
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
		long time = System.currentTimeMillis() - st;		
		System.out.println("Time to apply cplex (ms): " + time);
		return solution;
	}

	public static HashSet<OWLAxiom> repairByCPlex(String resPath, HashSet<HashSet<OWLAxiom>> multiSets){		
		// Extract all the axioms from set
		ArrayList<OWLAxiom> inputAxioms = ILPTools.getAxiomList(multiSets);	
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		
		long st = System.currentTimeMillis();
		try {
			// Translate OWL axioms to cplex representation as a model (.mps file)
			ILPAlgorithm.createModel(resPath+"models/", multiSets, inputAxioms);
			IloCplex cplex = new IloCplex();
			// Import the saved model
			cplex.importModel(resPath+"models/" + "ilpModel1.mps");
			// Set parameters for CPlex
			cplex.setParam(IloCplex.Param.MIP.Pool.RelGap, 0.1);
			// Begin to compute diagnosis
			cplex.solve();
			solution = ILPTools.getCplexResult(cplex, inputAxioms);
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
		long time = System.currentTimeMillis() - st;		
		System.out.println("Time to apply cplex (ms): " + time);
		return solution;
	}


}
