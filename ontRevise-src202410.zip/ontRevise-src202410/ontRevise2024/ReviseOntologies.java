package edu.njupt.radon.exp.ontRevise2024;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.debug.incoherence.relative.RelativeDebug;
import edu.njupt.radon.rank.RankWithMIPS;
import edu.njupt.radon.rank.RankWithMIPSUnion;
import edu.njupt.radon.rank.RankWithRebuttalOnt;
import edu.njupt.radon.rank.RankWithReliableOnt;
import edu.njupt.radon.rank.RankWithScore;
import edu.njupt.radon.rank.RankWithShapley;
import edu.njupt.radon.rank.RankWithSignatures;
import edu.njupt.radon.repair.ChooseSubsets;
import edu.njupt.radon.repair.RepairWithWeight;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ReviseOntologies {

	// Parameters to be configured
	String stableOntName;
	String unstableOntName;
	String ontoRoot;
	String resPath;
	String mupsPath;
	String infoPath;
	double thr = 0.5;
	String scoreFunction;
	// This parameter is required when resolving ucs group by group
	int ucNum = 10;
	int topk =1;
	String alg = "reviseWithMIPS"; // reviseWithMIPS, reviseSomeUcs
	
	// Variables to be used
	OWLOntology unstableOnt;
	OWLOntology stableOnt;
	HashSet<OWLAxiom> stableAxioms;
	HashSet<OWLAxiom> unstableAxioms;
	HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	long explainTime = 0, repairTime = 0, checkRedundancyTime = 0;
	
	
	public static void main(String[] args) {			
		ReviseOntologies revise = new ReviseOntologies();
		revise.reviseMapping();			
		//revise.reviseOnts();
	}
	
	public void reviseMapping() {
		/*String[] scoreFunctions = {
		"base", "score", "sig",  "shapley", 
		"mips_cos", "mips_euc", 
		"mipsUnion_cos", "mipsUnion_euc", 
		"rebuttalOnt_cos", "rebuttalOnt_euc", 
		"reliableOnt_cos", "reliableOnt_euc"};*/
		scoreFunction = "reliableOnt_euc";		
		
		String system = "OTMapOnto";//LogMapLt-cmt-ekaw ALOD2Vec-conference-ekaw  OTMapOnto-cmt-conference
		stableOntName = "ekaw-sigkdd"; // OTMapOnto-ekaw-sigkdd; OTMapOnto-cmt-conference  conference-edas
		unstableOntName = system+"-"+stableOntName;
		
		ontoRoot = "data/onto-mapping/";
		resPath = "results/reviseOnt/reviseOntGroup"+ucNum+"/"+unstableOntName+"/";
		mupsPath = "results/mups-conf2021/"+unstableOntName+"/explanations-log.txt";
		infoPath = "data/infoMapping/";
		
        this.ini();	
        this.doRevision();
	}
	
	public void reviseOnts()  {		
		// parameters to be configured
		/*String[] scoreFunctions = {
		"base", "score", "sig",  "shapley", 
		"mips_cos", "mips_euc", 
		"mipsUnion_cos", "mipsUnion_euc", 
		"rebuttalOnt_cos", "rebuttalOnt_euc", 
		"reliableOnt_cos", "reliableOnt_euc"};*/
		scoreFunction = "base";
		
		stableOntName = "km1500-1000-7"; // km1500-1000-8
		unstableOntName = "km1500-1000-8";  //km1500-1000-9
		
		resPath = "results/reviseOnt/"+stableOntName+"-"+unstableOntName+"/";
		mupsPath = "results/mups-km/"+this.stableOntName+"-"+unstableOntName+"/explanations-log.txt";
		ontoRoot = "data/onto-km/";
		infoPath = "data/info/";		
		
		this.ini();		
		this.doRevision();
	}	
    
    public void ini() {
    	File file = new File(resPath+"models/");
		if(!file.exists()){
			file.mkdirs();
		} 
		
		String sourceOntoPath = ontoRoot + stableOntName + ".owl";
		String targetOntoPath = ontoRoot + unstableOntName + ".owl";
		stableOnt = OWLTools.openOntology("file:" + sourceOntoPath);
		unstableOnt = OWLTools.openOntology("file:" + targetOntoPath);
		stableAxioms = new HashSet<OWLAxiom>(stableOnt.getLogicalAxioms());
		unstableAxioms = new HashSet<OWLAxiom>(unstableOnt.getLogicalAxioms());
		allAxioms.addAll(stableAxioms);
		allAxioms.addAll(unstableAxioms);
    }
    
    public void doRevision() {
    	// reviseWithMIPS, reviseOneUc, reviseSomeUcs
    	if(alg.equals("reviseWithMIPS")) {
    		doRevisionWithMIPS();
    	} else if(alg.equals("reviseSomeUcs")) {
    		this.doRevisionWithMUPS();
    	} else {
    		System.err.println("....");
    	}
    }
		
	public void doRevisionWithMIPS() {
		HashMap<String, HashSet<HashSet<String>>> ucMUPSStr = null;
		try {
			ucMUPSStr = Tools.readUcMUPS(mupsPath);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		System.out.println("num of mupsstr: "+ucMUPSStr.size());
		HashSet<HashSet<OWLAxiom>> conflicts = Tools.transferStrToMUPS(this.unstableOnt, ucMUPSStr);
		System.out.println("num of conflicts: "+conflicts.size());	
		
		if(conflicts.size()>0) {
			conflicts = ComputeMIPS.doCompute(conflicts);
			System.out.println("num of mips: "+conflicts.size());				
			HashSet<OWLAxiom> solution = this.computeSolution(conflicts);
			this.checkRedundancy(solution);
		}
			
		System.out.println("Time to repair (ms): " + this.repairTime);
		System.out.println("Time to check redundancy (ms): " + this.checkRedundancyTime);

	}
	
	public void doRevisionWithMUPS() {
		int topk = 1;
		 
		String logPath = resPath+scoreFunction+"-"+topk+"-log.txt";  
		/*File file = new File(logPath);
		if(file.exists()) {
			return;
		}*/
		
		System.setOut((new PrintStreamObject(logPath)).ps);	
		
    	HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
    	allAxioms.addAll(stableAxioms);
    	allAxioms.addAll(unstableAxioms);		
    	HashSet<OWLAxiom> finalSolution = new HashSet<OWLAxiom>();
    	
    	HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(allAxioms);
		System.out.println("ucs: "+ucs.size());
		RelativeDebug find = new RelativeDebug(allAxioms, unstableAxioms);
		//HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		boolean checkIncoherence = false;
		int i = 0;		
		int winUcNum = 0;
		long st = 0;
		
		this.explainTime = 0;
		for(OWLClass uc : ucs) {		
			st = System.currentTimeMillis();
			System.out.println("uc <"+(i++)+"> "+uc.toString());	
			if(checkIncoherence && ReasoningTools.isSatisfiable(allAxioms, uc)) {
				System.out.println(" This concept has turned to be satisfiable. ");	
				explainTime += System.currentTimeMillis() - st;
				continue;
			}
			winUcNum ++;			
			HashSet<HashSet<OWLAxiom>> clMUPS = find.getMUPS(uc);			
			conflicts.addAll(clMUPS);
			//CommonTools.printMultiSets(clMUPS, null);

			if(clMUPS==null || clMUPS.size()==0){
				System.err.println("  Cannot find mups for unsatisfiable concept: "+uc.toString());
				break;
			} 
			explainTime += System.currentTimeMillis() - st;
			
			if(winUcNum == ucNum) {			
				System.out.println("num of conflicts1: "+conflicts.size());	
				conflicts = ComputeMIPS.doCompute(conflicts);
				System.out.println("num of conflicts2: "+conflicts.size());	
				HashSet<OWLAxiom> solution = this.computeSolution(conflicts);
				allAxioms.removeAll(solution);
				this.unstableAxioms.removeAll(solution);
				finalSolution.addAll(solution);
				find = new RelativeDebug(allAxioms, this.unstableAxioms);
				conflicts.clear();
				checkIncoherence = true;
				winUcNum = 0;
			}
		}
		
		if(conflicts.size()>0) {
			HashSet<OWLAxiom> solution = this.computeSolution(conflicts);
			allAxioms.removeAll(solution);
			finalSolution.addAll(solution);
		}
		
					
		this.checkRedundancy(finalSolution);		
		
		System.out.println("\n** Is coherent? "+ReasoningTools.isCoherent(allAxioms));
		//System.out.println("** Is a minimal diagnosis? "+DiagnosisCorrectnessCheck.isMinimal(allAxioms, finalSolution));
		
		System.out.println("Time to explain (ms): " + this.explainTime);	
		System.out.println("Time to repair (ms): " + this.repairTime);
		System.out.println("Time to check redundancy (ms): " + this.checkRedundancyTime);
		
		OWLTools.manager.removeOntology(stableOnt);
		OWLTools.manager.removeOntology(unstableOnt);
	}
	
	public void checkRedundancy(HashSet<OWLAxiom> solution) {
		HashSet<OWLAxiom> finalSolution = new HashSet<OWLAxiom>();
		// filter redundant axioms in the final solution
		if(!this.scoreFunction.equals("base")) {
			allAxioms.removeAll(solution);
			System.out.println("   begin to check redundancy (axioms to be checked: "+solution.size()+")...");
			long st = System.currentTimeMillis();
			//System.out.println(" Current onto is coherent? "+doRea.isCoherent(allAxioms, null));
			for(OWLAxiom ax : solution) {
				allAxioms.add(ax);
				if(!ReasoningTools.isCoherent(allAxioms)) {
					finalSolution.add(ax);
					allAxioms.remove(ax);
				} else {
					System.out.println("   Redundant axiom: "+ax.toString());
				}
			}
			this.checkRedundancyTime += System.currentTimeMillis() - st;			
			allAxioms.addAll(finalSolution);
		} else {
			finalSolution.addAll(solution);
		}
		System.out.println("************************************ \n");	
			
		
		System.out.println("\n** All removed axioms:");
		int k = 1;
		for(OWLAxiom ax : finalSolution) {
			System.out.println((k++)+"> "+ax.toString());
		}
		System.out.println();
	}
	
   
	public HashSet<OWLAxiom> computeSolution(
			HashSet<HashSet<OWLAxiom>> conflicts) {
				
		HashMap<OWLAxiom, Double> axiomRankMap = new HashMap<OWLAxiom, Double>();
		HashSet<HashSet<OWLAxiom>> diags = new HashSet<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> solution = new HashSet<OWLAxiom>();
		
		String logPath = resPath+scoreFunction+"-"+topk+"-log.txt";  
		
    	System.setOut((new PrintStreamObject(logPath)).ps);	
    	
		long st = System.currentTimeMillis();
		if(scoreFunction.equals("base")) {				
			axiomRankMap = RankWithScore.computeRanks(conflicts);			
			//diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, 1000);		
			diags = conflicts;
		} else if(scoreFunction.equals("score")) {				
			axiomRankMap = RankWithScore.computeRanks(conflicts);
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("sig")) {	
			RankWithSignatures rs = new RankWithSignatures(this.stableOnt);
			axiomRankMap = rs.computeRanks(conflicts);	
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("shapley")) {	
			RankWithShapley rr = new RankWithShapley();
			axiomRankMap = rr.computeRanks(conflicts);
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
			
		} else if(scoreFunction.equals("mips_cos")) {			
			RankWithMIPS rr = new RankWithMIPS(conflicts, "cos", this.unstableOntName, this.infoPath, thr);
			axiomRankMap = rr.computeRanks();
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("mips_euc")) {			
			RankWithMIPS rr = new RankWithMIPS(conflicts, "euc", this.unstableOntName, this.infoPath, thr);
			axiomRankMap = rr.computeRanks();
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("mipsUnion_cos")) {			
			RankWithMIPSUnion rr = new RankWithMIPSUnion(conflicts, "cos", this.unstableOntName, this.infoPath, thr);
			axiomRankMap = rr.computeRanks();
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("mipsUnion_euc")) {			
			RankWithMIPSUnion rr = new RankWithMIPSUnion(conflicts, "euc", this.unstableOntName, this.infoPath, thr);
			axiomRankMap = rr.computeRanks();
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("rebuttalOnt_cos")) {			
			RankWithRebuttalOnt rr = new RankWithRebuttalOnt(conflicts, "cos", this.stableOntName, this.unstableOntName, this.infoPath, thr);
			axiomRankMap = rr.computeRanks();
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("rebuttalOnt_euc")) {			
			RankWithRebuttalOnt rr = new RankWithRebuttalOnt(conflicts, "euc", this.stableOntName, this.unstableOntName, this.infoPath, thr);
			axiomRankMap = rr.computeRanks();
			diags = ChooseSubsets.getSubsetsHighTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("reliableOnt_cos")) {			
			RankWithReliableOnt rr = new RankWithReliableOnt(conflicts, "cos", this.stableOntName, this.unstableOntName, this.infoPath, thr);
			axiomRankMap = rr.computeRanks();
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, topk);
		} else if(scoreFunction.equals("reliableOnt_euc")) {			
			RankWithReliableOnt rr = new RankWithReliableOnt(conflicts, "euc", this.stableOntName, this.unstableOntName, this.infoPath, thr);
			axiomRankMap = rr.computeRanks();
			diags = ChooseSubsets.getSubsetsLowTopk(conflicts, axiomRankMap, topk);			
		} 
		solution = CPlexSolution.repairByCPlex(resPath, diags);
		repairTime += System.currentTimeMillis() - st;
		
		// outputs
		/*System.out.println("axiom scores:");
		Tools.printAxiomScore(axiomRankMap);*/
		int i = 1;
		System.out.println("\n** Conflicts to be resolved:");		
		for(HashSet<OWLAxiom> conf : conflicts) {
			System.out.println(" conf <"+(i++)+"> ");
			for(OWLAxiom ax : conf) {
				System.out.println("    "+ax.toString()+" : "+axiomRankMap.get(ax));
			}
		}
		// check the revision result
		System.out.println("\n** Solution:");
		int k = 1;
		for(OWLAxiom ax : solution) {
			System.out.println((k++)+"> "+ax.toString()+" : "+axiomRankMap.get(ax));
		}
		System.out.println("************************************ \n");	
		
		return solution;
	}	

}
