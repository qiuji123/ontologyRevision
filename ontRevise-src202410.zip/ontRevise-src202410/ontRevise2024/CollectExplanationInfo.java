package edu.njupt.radon.exp.ontRevise2024;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class CollectExplanationInfo {
	
	public static void main(String[] args) throws Exception{
		readDiagResults();
	}
	
	public static void readDiagResults()  throws Exception{	
		String resPath = "results/mups-km/"; 
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(resPath+"results-exp.xls")),true); 
		outputHeader(output);
				
		String resFilePath = "";
		File f = new File(resPath);
		for(File ontoF : f.listFiles()) {	
			if(!ontoF.isDirectory()) {
				continue;
			}
			String ontoName = ontoF.getName();
			System.out.println("onto: "+ontoName);	
						
			resFilePath = resPath+ontoName+"/";	
			for(File logF : ontoF.listFiles()) {
				if(logF.isDirectory()) {
					continue;
				}
				output.print(ontoName);
				output.print("\t");
											
				outPutInfo(resFilePath+logF.getName(), output);
			}
		}
	}
	
	public static void outPutInfo(String filePath, PrintWriter output) throws Exception {
		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		
		int allUcNum = 0;
		
		int mipsNum = 0;
		int mipsUnionSize = 0;
		int oneMipsSize = 0;
		int minMips = 1000;
		int maxMips = 0;
		boolean mipsBegin = false;
		
		int mupsNumMax = 0;
		int mupsNumMin = 1000;
		int mupsNumTotal = 0;
		int ucMUPSNum = 0;
		boolean foundOneMIPS = false;
		boolean mupsBegin = false;
		
		String expTime = "1000000";
		
		String line ;
		while ((line=reader.readLine())!=null) {
			if(line.startsWith("ucs: ")) {
				String s = line.substring(line.indexOf(": ")+2);
				allUcNum = Integer.valueOf(s);
			} else if(line.startsWith("uc <") || line.startsWith("** Conflicts")) {
				if(ucMUPSNum != 0) {
					mupsNumTotal += ucMUPSNum;
					if(ucMUPSNum>mupsNumMax) {
						mupsNumMax = ucMUPSNum;
					}
					if(ucMUPSNum < mupsNumMin) {
						mupsNumMin = ucMUPSNum;
					}
					ucMUPSNum = 0;
				}				
				
			} else if(line.startsWith("Explanation <")) {
				mupsBegin = true;
			} else if(line.startsWith(" conf <")) {
				mipsBegin = true;
				if(oneMipsSize != 0 ) {
					foundOneMIPS = true;
				}
			} else if(line.startsWith("    ") && mipsBegin) {
				oneMipsSize ++;
			} else if(line.isEmpty() && mipsBegin) {
				mipsBegin = false;
				foundOneMIPS = true;			
			} else if(line.startsWith("Time to explain (ms): ")) {
				expTime = line.substring(line.indexOf(": ")+2);
			} else if(line.isEmpty() && mupsBegin) {
				mupsBegin = false;
				ucMUPSNum ++;
			}
				
			if(foundOneMIPS) {
				mipsNum ++;
				mipsUnionSize += oneMipsSize;
				if(oneMipsSize > maxMips) {
					maxMips = oneMipsSize;
				}
				if(oneMipsSize < minMips) {
					minMips = oneMipsSize;
				}
				oneMipsSize = 0;
				foundOneMIPS = false;
			}
		}
		
		System.out.println("      uc number : "+allUcNum);
		output.print(allUcNum);
		output.print("\t");
		
		System.out.println("      mupsNumTotal: "+mupsNumTotal);
		output.print(((mupsNumTotal*1.0)/allUcNum));
		output.print("\t");
		output.print(mupsNumMax);
		output.print("\t");
		output.print(mupsNumMin);		
		output.print("\t");
		
		output.print(mipsNum);
		output.print("\t");
		//System.out.println("      average size of an explanation: "+ ((mipsUnionSize*1.0)/expNum));
		output.print(((mipsUnionSize*1.0)/mipsNum));
		output.print("\t");
		//System.out.println("      max size of an explanation: "+maxMips);
		output.print(maxMips);
		output.print("\t");
		//System.out.println("      min size of an explanation: "+minMips);
		output.print(minMips);
		output.print("\t");
		//System.out.println("      explain time : "+expTime);
		output.print(expTime);
		output.println();
		
	}
	
	public static void outputHeader(PrintWriter  output){
		output.print("Onto");
	    output.print("\t");
		output.print("ucNum");		
		output.print("\t");
		
		output.print("mups number (avg)");		
		output.print("\t");
		output.print("mups number (max)");		
		output.print("\t");
		output.print("mups number (min)");		
		output.print("\t");
		
		output.print("#AllExp");
		output.print('\t');
		output.print("ExpSize_avg");
		output.print('\t');
		output.print("ExpSize_max");
		output.print('\t');
		output.print("ExpSize_min");
		output.print('\t');
		
		output.print("Explain Time(ms)");
		output.println();
	}
}
