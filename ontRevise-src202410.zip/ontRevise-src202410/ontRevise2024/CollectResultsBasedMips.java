package edu.njupt.radon.exp.ontRevise2024;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class CollectResultsBasedMips {
	
	public static void main(String[] args) throws Exception{
		readDiagResults();
	}
	
	public static void readDiagResults()  throws Exception{	
		// reviseConf2021  reviseOntMips
		String resPath = "results/reviseOnt/reviseOntGroup10/";
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(resPath+"results-revise.xls")),true); 
		outputHeader(output);
				
		String resFilePath = "";
		File f = new File(resPath);
		for(File ontoF : f.listFiles()) {	
			if(!ontoF.isDirectory()) {
				continue;
			}
			String ontoName = ontoF.getName();
			System.out.println("onto: "+ontoName);			
			resFilePath = resPath+ontoName+"/";	
			for(File logF : ontoF.listFiles()) {
				if(logF.isDirectory()) {
					continue;
				}
				output.print(Tools.getOntoName(ontoName));
				output.print("\t");
				
				String[] logName = logF.getName().split("-");
				System.out.println("   strategy : "+logName[0]);
				output.print(Tools.getStrategyName(logName[0]));
				output.print("\t");			
				System.out.println("   topk : "+logName[1]);
				output.print(logName[1]);
				output.print("\t");
											
				outPutInfo(resFilePath+logF.getName(), output);
			}
		}
	}
	

	
	public static void outPutInfo(String filePath, PrintWriter output) throws Exception {
		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));

		int removedAxioms = 0, rmAx0 = 0;
		long repTime = 0;   
		long checkTime = 0; 
		boolean diagnosisBegin = false;
		boolean unfilteredDiagBegin = false;
		
		String line ;
		while ((line=reader.readLine())!=null) {
			if(line.startsWith("** All removed axioms:") ){
				diagnosisBegin = true;
			} else if(diagnosisBegin && line.contains("> ")) {
				removedAxioms ++;
			
			} else if(line.startsWith("Time to repair")) {
				String tStr = line.substring(line.indexOf(": ")+2);
				repTime = Long.valueOf(tStr);
			} else if(line.startsWith("Time to check")) {
				String tStr = line.substring(line.indexOf(": ")+2);
				checkTime = Long.valueOf(tStr);
			} else if(line.startsWith("** Solution:")) {
				unfilteredDiagBegin = true;
			} else if(unfilteredDiagBegin && line.contains("> ")) {
				rmAx0 ++;
			} else if(unfilteredDiagBegin && line.trim().length() == 0) {
				unfilteredDiagBegin = false;
			}
		}
		
		System.out.println("      rmAx0 axioms : "+rmAx0);
		output.print(rmAx0);
		output.print("\t");
		System.out.println("      removed axioms : "+removedAxioms);
		output.print(removedAxioms);
		output.print("\t");
		System.out.println("      redundant axioms : "+(rmAx0-removedAxioms));
		output.print(rmAx0-removedAxioms);
		output.print("\t");
		System.out.println("      repair time : "+repTime);
		output.print(repTime);
		output.print("\t");
		System.out.println("      check time : "+checkTime);
		output.print(checkTime);
		output.println();
		
	}
	
	
	
	public static void outputHeader(PrintWriter  output){
		output.print("Onto Pair");
	    output.print("\t");
	    output.print("Strategy");
	    output.print("\t");
		output.print("topk");		
		output.print("\t");
		output.print("#Unfiltered Removed Axioms");
		output.print('\t');
		output.print("#Removed Axioms");
		output.print('\t');
		output.print("#Redundant Axioms");
		output.print('\t');
		output.print("Repair Time(ms)");
		output.print('\t');
		output.print("Check Redundancy Time(ms)");
		output.println();
	}




}
